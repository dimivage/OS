
#!/bin/bash
date

current_time=$(date +%s)
echo "current time in seconds: $current_time"
echo "double of current time: $((current_time * 2))"

for i in {1..20}
do 
	echo $i
done


